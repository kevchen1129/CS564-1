/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

#include "btree.h"
#include "filescan.h"
#include "exceptions/bad_index_info_exception.h"
#include "exceptions/bad_opcodes_exception.h"
#include "exceptions/bad_scanrange_exception.h"
#include "exceptions/no_such_key_found_exception.h"
#include "exceptions/scan_not_initialized_exception.h"
#include "exceptions/index_scan_completed_exception.h"
#include "exceptions/file_not_found_exception.h"
#include "exceptions/end_of_file_exception.h"
#include "exceptions/file_exists_exception.h"
#include "exceptions/page_not_pinned_exception.h"
#include "exceptions/page_pinned_exception.h"

//#define DEBUG

namespace badgerdb
{

// -----------------------------------------------------------------------------
// BTreeIndex::BTreeIndex -- Constructor
// -----------------------------------------------------------------------------

BTreeIndex::BTreeIndex(const std::string & relationName,
		std::string & outIndexName,
		BufMgr *bufMgrIn,
		const int attrByteOffset,
		const Datatype attrType)
{
    std::ostringstream idxStr;
    idxStr<<relationName<<'.'<<attrByteOffset;
    outIndexName = idxStr.str();
    BTreeIndex::attrByteOffset = (int)attrByteOffset;
    attributeType = attrType;
    headerPageNum = 1;

    bufMgr = bufMgrIn;
    try{
        BlobFile* newFile = new BlobFile(outIndexName, true);
        file = (File*)newFile;

        // meta_page
        Page* empty_page;
        PageId meta_pageId;
        bufMgr->allocPage(file, meta_pageId, empty_page);
        bufMgr->unPinPage(file, meta_pageId, true);
        bufMgr->readPage(file, meta_pageId, empty_page);
        IndexMetaInfo* metapage = (IndexMetaInfo*)empty_page;
        std::copy(relationName.begin(), relationName.end(), (*metapage).relationName);
        (*metapage).attrByteOffset = attrByteOffset;
        (*metapage).attrType = attrType;
        (*metapage).isRootLeafPage = true;
        headerPageNum = meta_pageId;

        // root_page
        Page* root_page;
        bufMgr->allocPage(file, rootPageNum, root_page);
        bufMgr->unPinPage(file,rootPageNum, true);
        bufMgr->readPage(file, rootPageNum, root_page);
        (*metapage).rootPageNo = rootPageNum;
        // create an empty leaf node at root
        LeafNodeInt* leafNode = (LeafNodeInt*) root_page;
        (*leafNode).validEntry_num = 0;
        (*leafNode).rightSibPageNo = 0;
        
        // std::cout << "File created: " << (*metapage).relationName << "\n";

        bufMgr->unPinPage(file, rootPageNum, true);
        bufMgr->unPinPage(file, meta_pageId, true);

        BTreeIndex::createInitialTree(relationName, bufMgrIn);

        bufMgr->flushFile(file);
    }catch(FileExistsException ex){
        //check for metafile
        BlobFile* newfile = new BlobFile(outIndexName, false);
        file = (File*) newfile;
        IndexMetaInfo* metapage_info;
        Page *meta_page;
        bufMgr->readPage(file, headerPageNum, meta_page);
        metapage_info = (IndexMetaInfo*) meta_page;
        std::cout << (*metapage_info).relationName << "  "<< relationName<< "\n";
        if(relationName.compare((*metapage_info).relationName)==0 
            && (*metapage_info).attrByteOffset==attrByteOffset 
            && (*metapage_info).attrType==attrType){
            rootPageNum = (*metapage_info).rootPageNo;
            return;
        }
        else{
            throw BadIndexInfoException("Metafile does not match!!");
        }
        bufMgr->unPinPage(file, headerPageNum, false);
    }catch(FileNotFoundException ex){
        std::cout<<"FileNotFoundException"<<std::endl;
    }
}

const void BTreeIndex:: createInitialTree(const std::string &relationName, BufMgr *bufMgrIn)
{
    FileScan fscan(relationName, bufMgr);

    try
    {
        RecordId scanRid;
        while(1)
        {
            fscan.scanNext(scanRid);
            //Assuming RECORD.i is our key, lets extract the key, which we know is INTEGER and whose byte offset is also know inside the record. 
            std::string recordStr = fscan.getRecord();
            const char *record = recordStr.c_str();
            int key = *((int *)(record + attrByteOffset));
            BTreeIndex::insertEntry((void *)&key, scanRid);
            // std::cout << "Extracted : " << key << std::endl;
        }
        bufMgr->flushFile(file);
    }
    catch(EndOfFileException e)
    {   
        
        bufMgr->flushFile(file);
        // std::cout << "Read all records" << std::endl;
    }
    // printPage(rootPageNum,false);
}
const void BTreeIndex::printPage(PageId p,bool t)
{
    Page*page;
    NonLeafNodeInt *nleaf;
    LeafNodeInt * leaf;
    bufMgr->readPage(file,p,page);
    std::cout<<"page================"<<p<<std::endl;
    if(t){
        leaf = (LeafNodeInt*)page;
        for(int i=0;i<leaf->validEntry_num;i++){
            std::cout<<leaf->keyArray[i]<<"\t";
        }
        std::cout<<"\n";
    }else{
        nleaf = (NonLeafNodeInt*)page;
        for(int i=0;i<nleaf->validEntry_num;i++){
            std::cout<<nleaf->keyArray[i]<<"\t";
        }
        std::cout<<"\n";
        for(int i=0;i<=nleaf->validEntry_num;i++){
            std::cout<<nleaf->pageNoArray[i]<<"\t";
        }
        std::cout<<"\n";
        std::cout<<"\n";
    }
    std::cout<<"page================end"<<std::endl;
    bufMgr->unPinPage(file,p,false);
}
// -----------------------------------------------------------------------------
// BTreeIndex::~BTreeIndex -- destructor
// -----------------------------------------------------------------------------

BTreeIndex::~BTreeIndex()
{
    try{
        
        bufMgr->flushFile(file);
        delete file;
    }catch(PagePinnedException e){
        std::cout<<e<<std::endl;
    }

}

// -----------------------------------------------------------------------------
// BTreeIndex::insertEntry
// -----------------------------------------------------------------------------

const void BTreeIndex::insertEntry(const void *key, const RecordId rid) 
{
    PageId now_pageNum = rootPageNum;
    Page* now_pageData;
    IndexMetaInfo* metapage_info;
    Page* meta_page;
    bufMgr->readPage(file, headerPageNum, meta_page);
    metapage_info = (IndexMetaInfo *)meta_page;
    bool leafIsRoot = metapage_info->isRootLeafPage;
    bufMgr->unPinPage(file, headerPageNum, false);

    LeafNodeInt* leafNode;
    NonLeafNodeInt* nonleaftNode;
    int tempKey = *(int*)key;
    PageId tempPid;
    std::stack<PageId> fatherPageNum_stack;

    bufMgr->readPage(file, now_pageNum, now_pageData);
    while(true){
        if (leafIsRoot)
        {
            leafNode = (LeafNodeInt*)now_pageData;
            if (leafNode->validEntry_num<INTARRAYLEAFSIZE)
            {
                int i = 0,index=0;
                while(i<leafNode->validEntry_num&&
                    tempKey>=leafNode->keyArray[i])i++;
                leafNode->validEntry_num++;
                index=i;
                i=leafNode->validEntry_num-1;
                while(i>index){
                    leafNode->keyArray[i]=leafNode->keyArray[i-1];
                    leafNode->ridArray[i]=leafNode->ridArray[i-1];
                    i--;
                }
                leafNode->keyArray[index]=tempKey;
                leafNode->ridArray[index]=rid;
                // insert over
                bufMgr->unPinPage(file, now_pageNum,true);
                break;
            }
            else
            {
                // split node
                PageId newPageId;
                Page* newPage;
                LeafNodeInt* newPageData;
                int newKey;
                bufMgr->allocPage(file, newPageId, newPage);
                newPageData = (LeafNodeInt*)newPage;
                newPageData->validEntry_num=0;
                for(int i=INTARRAYLEAFSIZE/2;i<INTARRAYLEAFSIZE;++i){
                    newPageData->keyArray[i-INTARRAYLEAFSIZE/2] 
                    = leafNode->keyArray[i];
                    newPageData->ridArray[i-INTARRAYLEAFSIZE/2] 
                    = leafNode->ridArray[i];
                    newPageData->validEntry_num++;
                }
                newPageData->rightSibPageNo = leafNode->rightSibPageNo;
                leafNode->validEntry_num = INTARRAYLEAFSIZE/2;
                leafNode->rightSibPageNo = newPageId;
                newKey = newPageData->keyArray[0];

                bufMgr->unPinPage(file, newPageId, true);
                bufMgr->unPinPage(file, now_pageNum,true);
                tempPid = now_pageNum;

                BTreeIndex::insertPageNode(fatherPageNum_stack,(void *)&newKey,1,now_pageNum,newPageId);

                if (tempKey>=newKey){
                    now_pageNum = newPageId;
                    bufMgr->readPage(file, now_pageNum, now_pageData);
                }else{
                    now_pageNum = tempPid;
                    bufMgr->readPage(file, now_pageNum, now_pageData);
                }
            }
        }
        else
        {
            nonleaftNode = (NonLeafNodeInt*)now_pageData;
            fatherPageNum_stack.push(now_pageNum);
            if (tempKey>=nonleaftNode->keyArray[nonleaftNode->validEntry_num-1]){
                tempPid = nonleaftNode->pageNoArray[nonleaftNode->validEntry_num];
            }else{
                for (int i = 0; i < nonleaftNode->validEntry_num; ++i){
                    if (tempKey<nonleaftNode->keyArray[i]){
                        tempPid = nonleaftNode->pageNoArray[i];
                        break;
                    }
                }

            }
            if(nonleaftNode->level==1){
                leafIsRoot=true;
            }
            bufMgr->unPinPage(file, now_pageNum, false);
            now_pageNum = tempPid;
            bufMgr->readPage(file, now_pageNum, now_pageData);
        }
    }
    bufMgr->flushFile(file);
    return;
}

const void BTreeIndex::insertPageNode(
    std::stack<PageId>& fatherPageNum_stack,
    const void* key,
    const int level,
    const PageId lpageNo,
    const PageId rpageNo)
{
    int tempKey = *(int *)key;
    if (fatherPageNum_stack.empty())
    {
        // create new rootPage
        Page* meta_page;
        IndexMetaInfo* metapage_info;
        Page* root_page;
        NonLeafNodeInt* root_page_info;
        bufMgr->readPage(file, headerPageNum, meta_page);
        metapage_info = (IndexMetaInfo*)meta_page;
        bufMgr->allocPage(file, rootPageNum, root_page);
        root_page_info = (NonLeafNodeInt*)root_page;

        metapage_info->isRootLeafPage = false;
        metapage_info->rootPageNo = rootPageNum;
        root_page_info->keyArray[0] = tempKey;
        root_page_info->pageNoArray[0] = lpageNo;
        root_page_info->pageNoArray[1] = rpageNo;
        root_page_info->validEntry_num = 1;
        root_page_info->level = level;
        bufMgr->unPinPage(file, headerPageNum, true);
        bufMgr->unPinPage(file, rootPageNum, true);
    }
    else
    {
        PageId now_pageNum = fatherPageNum_stack.top();
        fatherPageNum_stack.pop();
        Page* now_page;
        NonLeafNodeInt* now_page_info;
        bufMgr->readPage(file, now_pageNum, now_page);
        now_page_info = (NonLeafNodeInt*)now_page;
        if (now_page_info->validEntry_num<INTARRAYNONLEAFSIZE)
        {
            int i = 0,index=0;
            while(i<now_page_info->validEntry_num&&
                tempKey>=now_page_info->keyArray[i])i++;
            now_page_info->validEntry_num++;
            index=i;
            i=now_page_info->validEntry_num-1;
            while(i>index){
                now_page_info->keyArray[i]
                =now_page_info->keyArray[i-1];
                now_page_info->pageNoArray[i+1]
                =now_page_info->pageNoArray[i];
                i--;
            }
            now_page_info->keyArray[index]=tempKey;
            now_page_info->pageNoArray[index]=lpageNo;
            now_page_info->pageNoArray[index+1]=rpageNo;
            // insert over
            bufMgr->unPinPage(file, now_pageNum, true);
        }
        else
        {
                // split node
                PageId newPageId;
                Page* newPage;
                NonLeafNodeInt* newPageData;
                int newKey;
                bufMgr->allocPage(file, newPageId, newPage);
                newPageData = (NonLeafNodeInt*)newPage;
                newPageData->validEntry_num=0;
                for(int i=INTARRAYLEAFSIZE/2+1;i<INTARRAYLEAFSIZE;++i){
                    newPageData->keyArray[i-INTARRAYLEAFSIZE/2-1] 
                    = now_page_info->keyArray[i];
                    newPageData->pageNoArray[i-INTARRAYLEAFSIZE/2-1] 
                    = now_page_info->pageNoArray[i];
                    newPageData->validEntry_num++;
                }
                newPageData->pageNoArray[newPageData->validEntry_num] = 
                now_page_info->pageNoArray[INTARRAYLEAFSIZE];

                now_page_info->validEntry_num = INTARRAYLEAFSIZE/2;

                newKey = now_page_info->keyArray[INTARRAYLEAFSIZE/2];

                bufMgr->unPinPage(file, now_pageNum, true);
                bufMgr->unPinPage(file, newPageId,true);
                BTreeIndex::insertPageNode(fatherPageNum_stack,(void *)&newKey,level+1,now_pageNum,newPageId);

                if (tempKey>=newKey){
                    fatherPageNum_stack.push(newPageId);
                }else{
                    fatherPageNum_stack.push(now_pageNum);
                }
                BTreeIndex::insertPageNode(fatherPageNum_stack,(void *)&tempKey,level,lpageNo,rpageNo);
        }
    }
    bufMgr->flushFile(file);
}

// -----------------------------------------------------------------------------
// BTreeIndex::startScan
// -----------------------------------------------------------------------------

const void BTreeIndex::startScan(const void* lowValParm,
				   const Operator lowOpParm,
				   const void* highValParm,
				   const Operator highOpParm)
{

    scanExecuting = true;
    lowValInt = *(int*)lowValParm;
    highValInt = *(int*)highValParm;
    lowOp = lowOpParm;
    highOp = highOpParm;
    currentPageNum = rootPageNum;
    nextEntry = 0;

    LeafNodeInt* leafNode;
    NonLeafNodeInt* nonleafNode;
    IndexMetaInfo* metapage_info;
    Page* meta_page;
    PageId tempPid;
    bufMgr->readPage(file, currentPageNum, currentPageData);
    bufMgr->readPage(file, headerPageNum, meta_page);
    metapage_info = (IndexMetaInfo*)meta_page;
    bool leafIsRoot = metapage_info->isRootLeafPage;
    bufMgr->unPinPage(file, headerPageNum, false);
    while(!leafIsRoot)
    {
        nonleafNode = (NonLeafNodeInt*)currentPageData;
        if(lowValInt<nonleafNode->keyArray[0]){
            tempPid = nonleafNode->pageNoArray[0];
        }else if(lowValInt>=nonleafNode->keyArray[nonleafNode->validEntry_num-1]){
            tempPid = nonleafNode->pageNoArray[nonleafNode->validEntry_num];
        }
        else{
            int i=0;
            while(i<nonleafNode->validEntry_num
                &&lowValInt>=nonleafNode->keyArray[i]){
                i++;
            }
            tempPid = nonleafNode->pageNoArray[i];
        }
        if(nonleafNode->level==1){
            leafIsRoot=true;
        }
        bufMgr->unPinPage(file, currentPageNum, false);
        currentPageNum = tempPid;
        bufMgr->readPage(file, currentPageNum, currentPageData);
    }
    leafNode = (LeafNodeInt*)currentPageData;

    while(true)
    {
        if (leafNode->keyArray[nextEntry]>=lowValInt)
        {

            if(lowOp==3&&leafNode->keyArray[nextEntry]==lowValInt){
                
            }else{
                if(leafNode->keyArray[nextEntry]<highValInt){
                    break;
                }
                if(highOp==1&&leafNode->keyArray[nextEntry]==highValInt){
                    break;
                }
                if(leafNode->keyArray[nextEntry]>highValInt){
                    bufMgr->unPinPage(file, currentPageNum, false);
                    scanExecuting=false;
                    throw NoSuchKeyFoundException();
                }
            }
        }

        nextEntry++;
        if(nextEntry==leafNode->validEntry_num){
            tempPid = leafNode->rightSibPageNo;
            if(tempPid==0){
                bufMgr->unPinPage(file, currentPageNum, false);
                scanExecuting=false;
                throw NoSuchKeyFoundException();
            }
            bufMgr->unPinPage(file, currentPageNum, false);
            currentPageNum = tempPid;
            bufMgr->readPage(file, currentPageNum, currentPageData);
            leafNode = (LeafNodeInt*)currentPageData;
            nextEntry=0;
        }
    }
    //NoSuchKeyFoundException
    //
}

// -----------------------------------------------------------------------------
// BTreeIndex::scanNext
// -----------------------------------------------------------------------------

const void BTreeIndex::scanNext(RecordId& outRid) 
{
//IndexScanCompletedException

    if (!scanExecuting)
    {
        throw IndexScanCompletedException();
    }
    PageId tempPid;
    LeafNodeInt* leafNode = (LeafNodeInt*)currentPageData;
    if(scanExecuting){        
        if(leafNode->keyArray[nextEntry]<highValInt){
            outRid = leafNode->ridArray[nextEntry];
        }else if(leafNode->keyArray[nextEntry]==highValInt&&highOp==1){
            outRid = leafNode->ridArray[nextEntry];
        }else{
            throw IndexScanCompletedException();
        }
        nextEntry++;
        if(nextEntry==leafNode->validEntry_num){
            tempPid = leafNode->rightSibPageNo;            
            if(tempPid==0){
                try{
                    bufMgr->unPinPage(file, currentPageNum, false);
                }catch(PageNotPinnedException e){

                }                
                scanExecuting=false;
            }else{
                bufMgr->unPinPage(file, currentPageNum, false);
                currentPageNum = tempPid;
                bufMgr->readPage(file, currentPageNum, currentPageData);
                leafNode = (LeafNodeInt*)currentPageData;
                nextEntry = 0;
            }
        }

    }else{
        throw IndexScanCompletedException();
    }
}

// -----------------------------------------------------------------------------
// BTreeIndex::endScan
// -----------------------------------------------------------------------------
//
const void BTreeIndex::endScan() 
{
    scanExecuting = false;
    try{
        bufMgr->unPinPage(file, currentPageNum, false);
    }catch(PageNotPinnedException e){

    }
}

}

var searchData=
[
  ['end',['end',['../classbadgerdb_1_1_page_file.html#a752aac8594c77fc648b078d8973c0dea',1,'badgerdb::PageFile::end()'],['../classbadgerdb_1_1_page.html#a8e78cba69bef682a5427932485da4608',1,'badgerdb::Page::end()']]],
  ['endoffileexception',['EndOfFileException',['../classbadgerdb_1_1_end_of_file_exception.html#a491de6c6d5b2b1cb93b877b42969443e',1,'badgerdb::EndOfFileException']]],
  ['endscan',['endScan',['../classbadgerdb_1_1_b_tree_index.html#a78093b184e3ed6faf6edd8e90010583b',1,'badgerdb::BTreeIndex']]],
  ['exists',['exists',['../classbadgerdb_1_1_file.html#a864d59b12302c26b14967bd1d3e520bd',1,'badgerdb::File']]]
];
